package Graph;

import java.util.ArrayList;
import java.util.List;

public class VertexNode {

    int vertexVal;
    List<Integer> list = new ArrayList<Integer>();

    VertexNode(int val){
        this.vertexVal = val;
    }
}
